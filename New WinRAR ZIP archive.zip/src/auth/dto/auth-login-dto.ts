import { IsString } from 'class-validator';
import { isString } from 'util';

export class LoginCredentialDTO {
  @IsString()
  email: string;
  @IsString()
  password: string;
}
