export interface JwtPayload {
  email: string;
  isAdmin: boolean;
}
