export interface JwtPayload {
  email: string;
  isAdmin: boolean;
  f_name: string;
  l_name: string;
  id: number;
}
