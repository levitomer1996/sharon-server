export enum ArticleCategory {
  nutrition = 'nutrition',
  sustainability = 'sustainability',
  healthlifestyle = 'health/lifestyle',
  greenlandscape = 'greenlandscape',
}
